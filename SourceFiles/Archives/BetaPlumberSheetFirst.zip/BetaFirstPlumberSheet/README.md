[![Language](https://img.shields.io/badge/Swift-4.0-orange.svg?style=flat)](#)
[![Platform](https://img.shields.io/badge/iOS-9.3-lightgray.svg?style=flat)](#)
[![Devices](https://img.shields.io/badge/Devices-iPad-green.svg?style=flat)](#)
[![Version](https://img.shields.io/badge/App_Version-1.0-blue.svg?style=flat)](#)

## PlumberSheet - Work sheet app for in-house plumber engineers
1. [Description](#description)
2. [Copyright](#copyright)
3. [Contact](#contact)

## <a name="description">Description:</a>

```PlumberSheet``` - iPad application that...

## <a name="copyright">Copyright:</a>

Copyright © 2017 by <a href="http://suffolkoilsolutions.co.uk">Tom Veal</a> & <a href="http://iashchuk.com">Alexander Iashchuk</a>.

## <a name="contact">Contact:</a>

You can read, follow or drop me a line on my personal Twitter account - [@iAlexander13](https://twitter.com/iAlexander13).  
If you find any issues on the project, you can open a ticket.  
Pull requests are also welcome!

[![iAlexander - Нотатки громадянина України](https://raw.githubusercontent.com/iAlexander/PlumberSheet/master/Footer.jpg)](https://twitter.com/iAlexander13)
